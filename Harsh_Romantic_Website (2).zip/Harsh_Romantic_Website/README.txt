HARSH LOVE WEBSITE 💗

Files:
- index.html: your responsive romantic website.

HOW TO OPEN:
1. Download/extract the ZIP.
2. Double-click index.html to open it in your browser.

MUSIC:
For background music, place a royalty-free or personally licensed MP3 named:
romantic-music.mp3
in the same folder as index.html. Browsers require a tap/click before music can start.

PERSONALISE:
You can open index.html in Notepad and change the messages, names, colours, and sections.

PUBLISH ONLINE:
You can upload the extracted folder to a static website host such as GitHub Pages or Netlify to get a shareable link. The site is currently a ready-to-open local website; it is not yet published online.
